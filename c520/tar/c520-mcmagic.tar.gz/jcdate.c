/*----------------------------------------------------------------------
  jcdate.c : 

  Function to get the hour/date of the system
----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static int s0=0;
static int s1=0;
/*--------------------------------------------------
  jcdate: 
--------------------------------------------------*/
#ifdef JC_UNDERSCORES
void
jcdate_ (void)
#else /* JC_NO_UNDERSCORES */
void
jcdate (void)
#endif /* JC_UNDERSCORES */
{
  int i;
  time_t timesecs;
  struct tm *t;

  s0 = s1;
  s1 = (int) time( &timesecs );
  t = gmtime( &timesecs );
  printf ("JCDATE:: Now is %d/%d/%4d, %02d:%02d:%02d - Elapsed: %d seconds",
		  t->tm_mday, t->tm_mon+1, t->tm_year+1900,
		  t->tm_hour, t->tm_min, t->tm_sec,
		  s1 - s0);  
}

