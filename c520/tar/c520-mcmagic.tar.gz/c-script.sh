#! /bin/sh

readvalue () {
    dfl="$1"
    msg="$2"
    desc="$3"

    echo ''
    echo $msg
    echo -n "[ $dfl ] ? "
    read value
    value=${value:="$dfl"}
    echo "$desc <- $value"
}
    
echo '+---------------------------------------------------+'
echo '| This procedure will ask you about some parameters |' 
echo '| of your system. Please, answer all the questions. |' 
echo '| If you have any doubt, press Ctrl-C.              |' 
echo '+---------------------------------------------------+'
echo ''

readvalue `pwd` \
    "Directory where the CORSIKA executable is located:" path-exe 
pathexe="$value"

readvalue "c520-osf" \
    "Enter the executable name:" name-exe 
nameexe="$value"

readvalue "/data" \
    "Disk/path where the bulk of data will be stored:" data-disk
datadisk="$value"

readvalue "/data" \
    "Disk/path where the administration files will be stored:" adm-disk
admdisk="$value"

echo ''

readvalue "0" \
    "Final NICE value to use when running CORSIKA" niceval
niceval="$value"

readvalue "yes" \
    "Do you want to check the system load before running CORSIKA (yes/no)" MACH
MACH="$value"

echo ''

readvalue "$USER@$HOST" \
    "Enter the e-mail address to sent the log-mailing to" email-add
useradd="$value"

echo ''

echo 'Preparing daemon . . .'

cat <<EOF >dmy.sed
s=#USERADD#=$useradd=g
s=#DATADISK#=$datadisk=g
s=#ADMDISK#=$admdisk=g
s=#PATHEXE#=$pathexe=g
s=#NAMEEXE#=$nameexe=g
s=#NICE#=$niceval=g
EOF

sed -f dmy.sed magic-mc.daemon.tpl > mmd


if [ $MACH = "yes" ]; then

    cat <<EOF >> mmd
# get information about system load
if ( check_cpu_load() < 3 ) {
    send_mail( "\n## Top output:\n\n" . \`\$TOP -b\`, 1 );
    exit;

# make job
make_job;

# say bye, execute job and leave this program
exec "\$SYSDIR/job.cmds" 
    or croak "Cannot execute job file";
EOF

else

    cat <<EOF >> mmd
# get information about system load
check_cpu_load();

# make job
make_job;

# say bye, execute job and leave this program
exec "\$SYSDIR/job.cmds" 
    or croak "Cannot execute job file";
EOF

fi

echo 'MMD (MAGIC-MC.DAEMON) is ready to run.'

echo ''

echo 'The MAGIC-MC.DAEMON is designed to run from the crontab.'
echo 'Do you want me to change your crontab?'
readvalue "$USER@$HOST" \
    "Do you want me to change your crontab (yes/no)?" crntb
crntb="$value"

if [ $crntb = "yes" ]; then





