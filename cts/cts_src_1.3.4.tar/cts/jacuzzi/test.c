#include <string.h>
#include <stdio.h>
#include <math.h>
#include "ctsbase.h"
#include "ctshbook.h"
#include "ctscuts.h"
#include "ctsmath.h"


main()
{
  double dsig, d1, d2;

  d1 = 1e-110;
  d2 = 1e-200;

  printf ("test: %e\n", log10 (d1 * d2));

  dsig = cts_dsnd_quant (1e-300 / 2.);

  printf ("test: %f\n", dsig);

  exit();
}
