#include <stdio.h>
#include <math.h>
#include <math.h>
#include <stdio.h>
#include "ctsbase.h"
#include "ctsmath.h"
#include "ctshbook.h"
#include "ctscuts.h"
#include "nr.h"

int main()

  /* driver for routine cts_vfit_alpha ()
   */
{
  int i;

  double y[iNPT+1] = {0., 2089.00, 1565.00, 1221.00, 1068.00, 1028.00, 1068.00,
		      1066.00, 1074.00, 1071.00, 1255.00, 1228.00, 1313.00,
		      1531.00, 1701.00, 1919.00, 2116.00};

  double y_err[iNPT+1];

  double *pfpar, dchisq;

  RESULT presults;

  for (i = 1; i <= iNPT; i++)
    y_err[i] = (y[i] > dEPSILON) ? sqrt (y[i]) : 1.;

  dchisq = cts_dfit_alpha (y, y_err, 10., &presults, &pfpar, true);

  printf ("\n\n\t Non: %.1f\t", presults.dnr_ex);
  printf ("Noff: %.1f", presults.dnr_off);
  printf ("\t dex_err: %.1f chisq: %.1f\n", presults.dex_err, dchisq);
  printf ("\t Signal: %.4f \n\n", presults.dsignal);

  exit ();
}
