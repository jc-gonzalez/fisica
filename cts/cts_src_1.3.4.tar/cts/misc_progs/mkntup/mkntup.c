/*
 * Atmospheric Cherenkov Telescope Data Analysis Software
 * MPI f"ur Physik, M"unchen
 *
 */

/*
 * This File belongs to the program
 *
 *         M K N T U P
 *
 * Purpose: read CT-sys data from file and fill into an Ntuple
 *
 * Author: D. Kranich (12.10.99)
 *
 */
#include <stdio.h>
#include "ctsbase.h"
#include "ctshbook.h"

#define iNTUPLE_PARS 12

int main (int argc, char **argv)

{
  int i, ifs;

  char *cvarnam [iNTUPLE_PARS] = {"runtype", "mjd", "utc_sec", "ncttrig",
				  "d_on_d", "d_off_d", "mscw", "corex",
				  "corey", "RA", "DEC", "Energy"};

  bool bfinished;

  HBOOK_FILE hfile;
  FILE_TYPE datfile;


  /* check number of arguments
   */
  if (argc < 3)
    {
      fprintf (stdout, "call: mkntup 'dat-file ntuple-file-name' \n");
      exit (1);
    }

  /* initialize hbook
   */
  cts_vinit_hbook ();


  /* open data file (ascii)
   */
  datfile.pname = argv[1];
  datfile.pfile = NULL;
  datfile.acm = "r";

  cts_vopen_file (&datfile);


  /* open new ntuple
   */
  hfile.pvarnam = cts_pget_varnam_str (cvarnam, iNTUPLE_PARS);
  hfile.invar = iNTUPLE_PARS;
  hfile.pname = argv[2];
  hfile.ilrec = 8192;
  hfile.ilun = 20;
  hfile.iid = 1;

  hfile.copt = 'n';

  cts_vopen_hbook_file (&hfile);


  /* read in events and write them to ntuple
   */
  bfinished = false;

  while (!bfinished)
    {
      for (i = 0; i < iNTUPLE_PARS; i++)
	ifs = fscanf (datfile.pfile, "%f", hfile.pevtdat+i);

      /* calculate correct MJD
       */
      *(hfile.pevtdat+1) += 50000.f;

      if (ifs != EOF)
	cts_hfn (&hfile);

      else
	bfinished = true;
    }


  /* write ntuple to file
   */
  cts_hrout (hfile.iid, hfile.ilun, &hfile.copt);

  /* close ntuple
   */
  cts_hrend (&hfile);

  exit(0);
}
