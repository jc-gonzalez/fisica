/*
 * Atmospheric Cherenkov Telescope Data Analysis Software
 * MPI f"ur Physik, M"unchen
 *
 */

/*
 * This File belongs to the program
 *
 *         S E T I E
 *
 * Purpose: set Energy and Impakt parameter variables in a given
 * Ntuple
 *
 * Author: D. Kranich (15.01.2000)
 *
 */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "ctsbase.h"
#include "ctsmath.h"
#include "ctshbook.h"



/*
 * declaration of local functions
 */
static void vgive_description_and_exit ();

/*
 * functions
 */
static void vgive_description_and_exit ()

  /* give a description how to call this program
   * and exit
   */
{
  fprintf (stdout, "Usage: setie hbook-file\n\n");

  exit (iERRCODE);
}

void venergy (HBOOK_FILE *pntuple)

  /* this function returns the estimated impact parameter and energy for
   * a given event
   * input:
   * pntuple - struct containing data for one event
   * output:
   * pntuple - energy and impact parameter variable is set
   */
{
  float fdens, fcza;

  /* function parameters derived from MC-fit
   */
  float fepar[5] = {0.205844, 0.000172669, -0.00312944, 0.888975, 0.0017329};
  float fipar[4] = {26.1133, 131.337, -345.976, 0.486899};

  /* pointers to variables in event data of ntuple
   */
  static float *pdist, *psize, *pwidth, *plength, *paltdeg, *penergy, *pimpact;

  static bool binit = true;

  if (binit)
    {
      /* get location of different variable names in event-data
       */
      pdist   = cts_pset_nam (pntuple, "BDIST");
      psize   = cts_pset_nam (pntuple, "BSIZE");
      pwidth  = cts_pset_nam (pntuple, "BWIDTH");
      plength = cts_pset_nam (pntuple, "BLENGTH");
      penergy = cts_pset_nam (pntuple, "BEnergy");
      paltdeg = cts_pset_nam (pntuple, "BALTdeg");
      pimpact = cts_pset_nam (pntuple, "BimpactR");

      binit = false;
    }


  /* first calculate impact parameter, energy afterwards
   */
  fdens = (float) mdiv (*psize, *pwidth * *plength);
  fcza  = (float) cos ((90. - (double) *paltdeg) * dPIDIV180);

  *pimpact = (fipar[0] + fipar[1] * *pdist + fipar[2] * *pwidth)
    * (1.f / fcza + fipar[3] / m2 (fcza)) / (1.f + fipar[3]);

  *penergy = (fepar[0] + fepar[1] * fdens + fepar[2] * *pimpact
	      + fepar[3] * *plength + fepar[4] * *plength * fdens)
    * (1.f / m2 (fcza) + 0.2f / m4 (fcza)) / 1.2f;
}

#undef CFUNCNAME


#define CFUNCNAME "main"

int main (int argc, char **argv)

{
  int i, imax;

  HBOOK_FILE ntuple_in, ntuple_out;


  if (argc < 2)
    vgive_description_and_exit ();


  /* initialize hbook
   */
  cts_vinit_hbook ();


  /* open input and output Ntuple
   */
  ntuple_in.pname = argv[1];
  ntuple_in.copt = ' ';

  cts_vopen_hbook_file (&ntuple_in);


  ntuple_out.pname = "setie.hbook";
  ntuple_out.pvarnam = ntuple_in.pvarnam;
  ntuple_out.invar = ntuple_in.invar;
  ntuple_out.ilrec = ntuple_in.ilrec;
  ntuple_out.copt = 'n';
  ntuple_out.iid = 2;

  cts_vopen_hbook_file (&ntuple_out);

  /* reset pointer to input ntuple evt data
   */
  ntuple_out.pevtdat = ntuple_in.pevtdat;


  /* loop over all events, set Energy and Impakt parameter and store
   * results
   */
  imax = ntuple_in.inr_events;

  for (i = 1; i <= imax; i++)
    {
      cts_hgnf (&ntuple_in, i);

      /* set energy and impact parameter
       */
      venergy (&ntuple_in);

      cts_hfn (&ntuple_out);
    }


  /* write ntuple to file & close it
   */
  cts_hrout (ntuple_out.iid, ntuple_out.ilun, &ntuple_out.copt);
  cts_hrend (&ntuple_out);
  cts_hrend (&ntuple_in);

  exit(0);
}

#undef CFUNCNAME
