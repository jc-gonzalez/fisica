/* prevent multiple includes
 */
#ifndef CALCUTTA_H
#define CALCUTTA_H 1


#ifndef __cplusplus

/* we're not dealing with C++
 * if true was not defined before define boolean stuff
 */
#ifndef true
typedef int bool;
#define true 1
#define false 0
#endif

#endif



/*
 *             STRUCTURES and related
 *
 */
/* the first enum must have '0', the spacing must be '1' and the order
 * (CUTNAME) must match the definition of cut_nam in calcutta.c
 */
typedef enum {LENGTH = 0, WIDTH, DIST, DENSITY, ALPHA, MAXCUT} CUTNAME;

typedef enum {UPPER = 0, LOWER, MAXBOUND} CUT_BOUND;

typedef enum {FIXED = 0, VARIABLE, MAXPAR} PARTYPE;


/* number of cut variables and number of minuit variables per cut
 * (the additional variable contains the cut-id); if iCUT_PARS is
 * changed one has to adopt mncut below
 */
#define iCUT_PARS 8
#define iMINUIT_CPARS 9

/* structure containing all cut information
 */
typedef struct cut_data
{
  CUTNAME ecutnam;
  CUT_BOUND cbound;
  PARTYPE epartype;
  double dcut_pars[iCUT_PARS];
  double dcut_perr[iCUT_PARS];
  struct cut_data *p2next;
} cut_data_list;

typedef struct cut_data CUT;


/*
 *             DEFINES
 *
 */
/* keywords used for reading the cut parameter file
 * do not change the order of these keywords
 * (calcutta.c and get_param.c)
 */
#define iKEYWORDARGS 1
#define cKEYWORD01   " icutnr %d"
#define cKEYWORD02   " cbound %d"
#define cKEYWORD03   " partype %d"
#define cKEYWORD04   " bdefstartvals %d"

#define cRES_FILE_NAME "calcutta.results.txt"
#define cPS_FILE_NAME  "calcutta.ps"   

/* defs for histogram booking (get_cuts.c)
 */
#define cHTIT ";ALPHA;nr. evts"
#define iHALPHA_ID 100
#define fXLO  0.f
#define fXHI  90.f
#define iBINX 18


/* defines used in plot_res.c
 */
#define iHCUT_ID    200
#define iFUNPOINTS  100       /* array size used for function plot */
#define iCUTPOINTS  20        /* array size used for cut plot */
#define fMINLOGS    1.5f      /* min. of log (size) */
#define fMAXLOGS    3.5f      /* max. of log (size) */
#define fMINCOST    0.5f      /* min. of cos (theta) */
#define fMAXCOST    1.0f      /* max. of cos (theta) */



/*
 *        MACROS
 *
 */
/* these macros are used to set and read the cut-identify variables
 * (passed as minuit variable)
 * a - enum 'CUTNAME'
 * b - enum 'CUT_BOUND'
 * c - cut id (even if upper, odd if lower cut)
 */
#define mset_cut_id(a, b, c)                                               \
 do {if ((a) < 0 || (a) >= MAXCUT || ((b) != UPPER && (b) != LOWER))       \
       cts_merror ("%s: variables out of range\n", "mset_cut_id");         \
     else                                                                  \
       c = (double) (a) * 10. + (double) (b);                              \
    }                                                                      \
 while (0)

#define mget_cut_id(a, b, c)                                               \
 do {a = (CUTNAME) (0.5 + (c) / 10.);                                      \
     b = (CUT_BOUND) (0.5 + fmod (c, 2.));                                 \
    }                                                                      \
 while (0)



/* define cut-function (this macro is similar to mncut, defined in ctscuts.h,
 * but the image pars are passed via the DLIST_EL here)
 * a: array of cut parameters
 * b: DLIST_EL struct for one event
 */
#define mncut_cal(a, b) \
 (*a + *(a+1) * b->ddist_sq + *(a+2) * b->dmcza + b->dmls * (*(a+3)  \
  + *(a+4) * b->ddist_sq + *(a+5) * b->dmcza) + b->dmls_sq * (*(a+6) \
  + *(a+7) * b->ddist))


/*
 *   GLOBAL FUNCTIONS
 */
/* returns pointer to first element in a linked list; one element contains
 * information for a single cut;  defined in get_param.c
 */
extern CUT *pget_parfile (char *);

/* calculates the significance of a set of cuts;
 * defined in get_cuts.c
 */
extern double dcut_eff (double *, int, DLIST_EL *, RESULT *, bool, char *,
			char *[]);


/* fit function to ALPHA distribution and calculate event numbers
 * and significance
 */
extern void vfit_alpha (double *, double *, double, RESULT *, double **, bool);

/* plots shape of cuts and final ALPHA distribution
 */
extern void vplot_res (RESULT *, int, double, double *,	char *, double *, int,
		       char *[]);

#endif  /* CALCUTTA_H */
