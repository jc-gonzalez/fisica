#include <stdio.h>
#include <math.h>
#include "ctsbase.h"
#include "ctsmath.h"
#include "ctshbook.h"
#include "ctshplot.h"
#include "ctscuts.h"
#include "calcutta.h"

/*
 * declaration of local functions
 */
static void vplot_fun (double *);
static void vplot_cut (double *, char *, CUT_BOUND, double);


static void vplot_fun (double *pfpar)

  /* this function plots the fit-function for the ALPHA distribution
   * defined by the function parameters pfpar (must match definition in
   * cts_dfit_alpha)
   */
{
  int i;

  double dsigma, dgauss;
  float fx[iFUNPOINTS], fy[iFUNPOINTS], fyb[iFUNPOINTS];

  /* sigma = pfpar[4] might be '0.' so use dEPSILON instead
   */
  dsigma = (fabs (pfpar[4]) > dEPSILON) ? fabs (pfpar[4]) : dEPSILON;


  /* set array of abszissa- and function values (90. = ALPHAmax)
   */
  for (i = 0; i < iFUNPOINTS; i++)
    {
      fx[i] = (float) (90. * mdiv (i, iFUNPOINTS));

      fyb[i] = (float) (pfpar[1] + pfpar[2] * m2 (fx[i]));

      dgauss = exp (-0.5 * m2 (fx[i] / dsigma)) / dSQRT_2PI / dsigma;
      fy[i] = (float) (pfpar[1] + pfpar[2] * m2 (fx[i]) + pfpar[3] * dgauss);
    }


  cts_igset ("PLCI", 3);
  cts_igset ("LTYP", 2);
  cts_hplfun (fx, fyb, iFUNPOINTS, ' ');
  cts_igset ("PLCI", 4);
  cts_igset ("LTYP", 1);
  cts_hplfun (fx, fy, iFUNPOINTS, ' ');
}


static void vplot_cut (double *pcpar, char *pcutnam, CUT_BOUND cbound,
		       double ddist)

{
  int j, k;

  char *pstr, *ptit;

  float flogs, fcost, fdlogs, fdcost;

  static bool binit = true;

  DLIST_EL evt, *pevt;

  static HISTO hcut = {"", iHCUT_ID, iCUTPOINTS, iCUTPOINTS, fMINLOGS, fMAXLOGS,
		       fMINCOST, fMAXCOST, 0.f};


  if (binit)
    {
      cts_vbook_hist (&hcut);
      pevt = &evt;

      binit = false;
    }


  cts_hreset (hcut.iid, "");

  fdcost = (float) mdiv ((fMAXCOST - fMINCOST), iCUTPOINTS);
  fdlogs = (float) mdiv ((fMAXLOGS - fMINLOGS), iCUTPOINTS);

  for (j = 0; j < iCUTPOINTS; j++)
    for (k = 0; k < iCUTPOINTS; k++)
      {
	fcost = fMINCOST + fdcost * ((float) j + 0.5f);
	flogs = fMINLOGS + fdlogs * ((float) k + 0.5f);

	evt.ddist    = ddist;
	evt.ddist_sq = m2 (ddist);
	evt.dmcza    = (double) fcost - dNOMCOSZA;
	evt.dmls     = (double) flogs - dNOMLOGSIZE;
	evt.dmls_sq  = m2 (evt.dmls);

	cts_hfill (hcut.iid, flogs, fcost, mncut_cal (pcpar, pevt));
      }


  cts_igset ("TXAL", 20.f);
  cts_hplset ("XLAB", 2.f);
  cts_hplset ("HCOL", 4.f);
  cts_hplot (hcut.iid, "SURF4", "", 0);
  pstr = cts_pstrcat (2, ";Log (SIZE); Cos (theta);", pcutnam);
  cts_hpltit (pstr);
  cts_hplset ("HCOL", 0.f);

  cts_igset ("CHHE", 0.02f);
  pstr = (cbound == UPPER) ? " upper cut" : " lower cut";
  ptit = cts_pstrcat (2, pcutnam, pstr);
  cts_itx (2.2f, 1.03f, ptit);
  cts_igset ("CHHE", 0.015f);

  pstr = cts_preal_to_str (ddist, 2, "(DIST\"J# %.2f)");
  cts_itx (2.2f, 1.0f, pstr);
}


#define CFUNCNAME "vplot_res"

void vplot_res (RESULT *presults, int ihid, double dchisqu, double *pfpar,
		char *ptit, double *pxval, int inc, char *pcutnam[])

  /* plots shape of cuts and final ALPHA distribution
   * input:
   * presults - struct containing cut results
   * ihid     - id of ALPHA histogram
   * dchisqu  - chi^2 of function fitted to ALPHA distribution
   * pfpar    - array of fit function parameters
   * ptit     - title of plot
   * pxval    - array of cut parameters
   * inc      - number of cuts (fixed or variable)
   * pcutnam   - array of cut names
   */
{
  int i, k, ilun;
  char *pstr;

  double dalpha;
  double *pcpar;

  CUTNAME cnam;
  CUT_BOUND cbound;


  /* open ps-file
   */
  cts_vkuopen (&ilun, cPS_FILE_NAME, "UNKNOWN");
  cts_igmeta (-ilun, -111);
  cts_hplsiz (20., 16., ' ');


  /* produce cut-plots
   */
  for (i = 0; i < inc; i++)
    {
      k = i * iMINUIT_CPARS;

      /* pcpar points to array of cut parameters (for one cut)
       */
      pcpar = &pxval[k+1];

      /* get cut type and call plot function
       */
      mget_cut_id (cnam, cbound, pxval[k]);
      vplot_cut (pcpar, pcutnam[cnam], cbound, 0.6);
      vplot_cut (pcpar, pcutnam[cnam], cbound, 0.9);


      /* remember the ALPHA cut value
       */
      if (cnam == ALPHA) dalpha = pxval[k+1];
    }


  /*
   * plot ALPHA distribution and the fit function (vplot_fun must be called
   * after cts_hplot)
   */
  cts_igset ("MTYP", 21);
  cts_hplset ("YGTI", -0.5);
  cts_hplot (ihid, "EP", "", 0);
  vplot_fun (pfpar);
  cts_hpltit (";ALPHA \"M# deg. \"N#; N?ON!, N?b!");


  /* plot text on ALPHA plot
   */
  cts_iselnt (0);
  cts_igset ("TXAL", 20.f);
  cts_igset ("CHHE", 0.03f);
  cts_itx (0.5f, 0.85f, ptit);

  cts_igset ("CHHE", 0.015f);
  cts_itx (0.55f, 0.67f, "Significance for");

  pstr = cts_preal_to_str (dalpha, 2, "ALPHA \"W# %.2f^o!");
  cts_itx (0.55f, 0.64f, pstr);

  pstr = cts_preal_to_str (presults->dsignal, 1, "%.1f [s]");
  cts_itx (0.55f, 0.61f, pstr);

  cts_igset ("TXAL", 0.f);
  pstr = cts_preal_to_str (presults->dnr_ex, 0, "excess\"J# %.0f");
  cts_itx (0.7f, 0.50f, pstr);

  pstr = cts_preal_to_str (presults->dnr_off, 0, "background\"J# %.0f");
  cts_itx (0.7f, 0.47f, pstr);

  pstr = cts_preal_to_str (dchisqu, 2, "chisquare\"J# %.2f");
  cts_itx (0.7f, 0.44f, pstr);

  pstr = cts_pint_to_str (iNPT-iMA, "DOF.: %d");
  cts_itx (0.7f, 0.41f, pstr);


  /* close higz window
   */
  cts_igmeta (999, 0);
  cts_hplend ();
  cts_vkuclos (ilun, " ");
}

#undef CFUNCNAME
