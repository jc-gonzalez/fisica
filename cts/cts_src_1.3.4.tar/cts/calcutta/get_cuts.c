/*
 * Atmospheric Cherenkov Telescope Data Analysis Software
 * MPI f"ur Physik, M"unchen
 *
 */

/*
 * This File belongs to the program
 *
 *         C A L C U T T A
 *
 * Purpose: calculates best cuts for a given on- and off-data Ntuple
 *
 * Author: D. Kranich
 *
 */
#include <math.h>
#include <stdio.h>
#include "ctsbase.h"
#include "ctsmath.h"
#include "ctshbook.h"
#include "ctscuts.h"
#include "calcutta.h"

#define CFUNCNAME "dcut_eff"

double dcut_eff (double *xval, int inc, DLIST_EL *pon_list, RESULT *presults,
		 bool bfinished, char *ptit, char *pcutnam[])

  /* this function calculates (and returns) the significance of a given
   * set of cuts;
   * xval      - array containing the cut-parameters
   * inc       - number of cuts (fixed or variable)
   * pon_list  - pointer to list of on-data
   * presults  - struct containing the final results
   * bfinished - true if minuit converged
   * ptit      - title used for final plots
   * pcutnam   - array of cut names
   */
{
  int i, ibin, j, k;

  double dcutval, dchisq;

  static double **pcpar, *pfpar;

  static double dalpha_max = dALPHA_SHI, *palpha_max = &dalpha_max;

  /* vectors are used within Numerical Recipes, so they start at '1'
   * not '0' -> one additional double
   */
  static double y[iNPT+1], y_err[iNPT+1];

  static bool bcut, binit = true;

  CUTNAME cnam;
  CUT_BOUND cbound;

  DLIST_EL *pevt;

  HBOOK_FILE hfile;
  HISTO halpha = {cHTIT, iHALPHA_ID, iBINX, 0.f, fXLO, fXHI, 0.f, 0.f, 0.f};


  if (binit)
    {
      /* allocate array of cut-parameter pointers and reset them
       */
      pcpar = cts_mmalloc (double *, MAXCUT * MAXBOUND, CFUNCNAME);

      for (i = 0; i < MAXCUT * MAXBOUND; i++)
	pcpar[i] = NULL;

      /* set pointers to cut-parameters
       */
      for (i = 0; i < inc; i++)
	{
	  /* get cut name and boundary type (upper or lower cut)
	   * (xval[k] is a flag which identifies the cut; the cut
	   *  parameters start at xval[k+1])
	   */
	  k = i * iMINUIT_CPARS;
	  mget_cut_id (cnam, cbound, xval[k]);

	  j = (int) (cnam * MAXBOUND + cbound);
	  pcpar[j] = &xval[k+1];


	  if (cnam == ALPHA && cbound == UPPER)
	    palpha_max = &xval[k+1];
	}

      binit = false;

    }   /* END  if (binit) */


  /* open hbook file and book histogram when finished
   */
  if (bfinished)
    {
      hfile.pname = "calcutta.hbook";
      hfile.copt = 'N';
      hfile.ilrec = 1024;
      hfile.iid = -1;

      cts_vopen_hbook_file (&hfile);

      cts_vbook_hist (&halpha);
    }


  /*
   * loop over all ON events and apply cuts
   */
  pevt = pon_list;
  cts_vreset_darray (y, iNPT+1);

  while (pevt != NULL)
    {
      /* loop over all defined cuts (length_up, length_lo ...)
       */
      bcut = false;

      dcutval = (pcpar[0] != NULL) ? mncut_cal (pcpar[0], pevt) : 1e10;
      bcut |= ((dcutval - pevt->dlength) > 0.) ? false : true;

      dcutval = (pcpar[1] != NULL) ? mncut_cal (pcpar[1], pevt) : -1e10;
      bcut |= ((dcutval - pevt->dlength) < 0.) ? false : true;

      dcutval = (pcpar[2] != NULL) ? mncut_cal (pcpar[2], pevt) : 1e10;
      bcut |= ((dcutval - pevt->dwidth) > 0.) ? false : true;

      dcutval = (pcpar[3] != NULL) ? mncut_cal (pcpar[3], pevt) : -1e10;
      bcut |= ((dcutval - pevt->dwidth) < 0.) ? false : true;

      dcutval = (pcpar[4] != NULL) ? mncut_cal (pcpar[4], pevt) : 1e10;
      bcut |= ((dcutval - pevt->ddist) > 0.) ? false : true;

      dcutval = (pcpar[5] != NULL) ? mncut_cal (pcpar[5], pevt) : -1e10;
      bcut |= ((dcutval - pevt->ddist) < 0.) ? false : true;

      dcutval = (pcpar[6] != NULL) ? mncut_cal (pcpar[6], pevt) : 1e10;
      bcut |= ((dcutval - pevt->ddens) > 0.) ? false : true;

      dcutval = (pcpar[7] != NULL) ? mncut_cal (pcpar[7], pevt) : -1e10;
      bcut |= ((dcutval - pevt->ddens) < 0.) ? false : true;


      /* update ALPHA distr. array and histo, if event isn't cut
       */
      if (!bcut)
	{
	  /* cts_malpha_bin returns the bin number in C convention (first
	   * element has index '0' and must be transformed to Num. Recipes
	   * convention)
	   */
	  ibin = 1 + cts_malpha_bin (pevt->dalpha);

	  /* y might not cover the whole ALPHA range
	   */
	  if (ibin <= iNPT) y[ibin] += 1;


	  /* fill histogram when finished
	   */
	  if (bfinished)
	    cts_hfill (halpha.iid, (float) fabs (pevt->dalpha), 0.f, 1.f);
	}


      pevt = pevt->p2next;

    }    /* END of    while (pevt != NULL) */




  /* derive fit and results for ALPHA distribution
   * (fill array of errors first)
   */
  for (i = 1; i <= iNPT; i++)
    {
      y_err[i] = (y[i] > dEPSILON) ? sqrt (y[i]) : 1.;
      printf ("%6.2f, ", y[i]);
    }

  dchisq = cts_dfit_alpha (y, y_err, *palpha_max, presults, &pfpar, bfinished);


  printf ("\nsig: %f, ex: %f, off: %f, chisq: %.1f\n\n", presults->dsignal,
	  presults->dnr_ex, presults->dnr_off, dchisq);



  /* produce plots, save histo and close hbook file when finished
   */
  if (bfinished)
    {
      vplot_res (presults, halpha.iid, dchisq, pfpar, ptit, xval, inc, pcutnam);
      cts_hrout (halpha.iid, hfile.ilun, &hfile.copt);
      cts_hrend (&hfile);
    }

  return (-presults->dsignal);
}

#undef CFUNCNAME
