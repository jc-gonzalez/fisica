#include <string.h>
#include <stdio.h>
#include <math.h>
#include "ctsbase.h"
#include "ctshbook.h"
#include "ctscuts.h"
#include "ctsmath.h"
#include "nr.h"

/* definition of global array cut_names - used to access cuts
 * by name
 */
const char cut_names [MAX_CUT_TYPE] [iMAX_CUT_NAME_LEN] =
{"nocut", "filter", "scuts", "dscuts97", "dscuts", "dscuts2", "ds96", "ds97",
 "ds98", "ds00", "ds97hiz", "hzacuts", "fs_cut", "croberto", "ctest"};


/*
 * declaration of all local functions
 */
static bool bnocut       (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bfilter_cuts (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bscuts       (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bdscuts97    (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bdscuts      (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bdscuts2     (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bds96        (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bds97        (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bds98        (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bds00        (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bds97hiz     (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bhza_cuts    (HBOOK_FILE *, RUN_TYPE, bool *);
static bool bfs_cut      (HBOOK_FILE *, RUN_TYPE, bool *);
static bool broberto_cut (HBOOK_FILE *, RUN_TYPE, bool *);
static bool btest        (HBOOK_FILE *, RUN_TYPE, bool *);

/* array of all defined cuts - must match definition of CUT_TYPE
 * in cut.h
 */
static bool (*const cut_funcs [MAX_CUT_TYPE]) () =
{bnocut, bfilter_cuts, bscuts, bdscuts97, bdscuts, bdscuts2, bds96, bds97,
 bds98, bds00, bds97hiz, bhza_cuts, bfs_cut, broberto_cut, btest};


/* array of all defined run types - must match definition of RUN_TYPE
 * in cut.h
 */
static const float fruntype [MAX_RUN_TYPE] = {0.f, 1.f, 2.f};


/*
 *
 *  cut functions
 *
 */
static bool bnocut (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* set bsig to true and return true
   * (event is considered signal event and not cut)
   */
{
  *bsig = true;

  return (true);
}


static bool bnocut2 (HBOOK_FILE *dummy)

  /* function used when ther's no user supplied cut function - it just
   * returns true (passed data are ignored)
   */
{
  return (true);
}


static bool bfilter_cuts (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply filter cuts
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...)
   * bsig    - true for events in signal region, else false
   */
{
  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to filter variables in event data of ntuple
   */
  static float *psize, *pmaxpix, *pnumpix, *pruntyp;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pruntyp = cts_pset_nam (pntuple, cRUNTYPE);
      pmaxpix = cts_pset_nam (pntuple, cMAXPIX12);
      pnumpix = cts_pset_nam (pntuple, cNUMPIXCB);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* apply filter cuts;
   * use rtyp to get runtype from file scope array 'fruntype'
   */
  if (*psize > 60.f && *pmaxpix > 3999.f && *pnumpix > 4000.f
      && *pnumpix < 92000.f && fruntype[rtyp] == *pruntyp)
    {
      /* all passed events are considered signal events
       */
      *bsig = true;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bscuts (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply scuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to scut variables in event data of ntuple
   */
  static float *pdist, *pconc, *pwidth, *plength, *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      pdist   = cts_pset_nam (pntuple, cDIST);
      pconc   = cts_pset_nam (pntuple, cCONC);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* apply scuts - including filter cuts
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) && *pdist < 1.1f && *pdist > 0.5f
      && *plength < 0.3f && *plength > 0.16f && *pwidth < 0.15f
      && *pwidth > 0.07f && *pconc > 0.4f)
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}

static bool broberto_cut (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply roberto cuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to scut variables in event data of ntuple
   */
  static float *pdist, *pconc, *pwidth, *plength, *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      pdist   = cts_pset_nam (pntuple, cDIST);
      pconc   = cts_pset_nam (pntuple, cCONC);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* apply scuts - including filter cuts
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) && *pdist < 1.15f
      && *pdist > 0.15f && *plength < 0.3f && *plength > 0.08f
      && *pwidth < 0.2 && *pwidth > 0.03f)
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bfs_cut (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply false source cut - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to scut variables in event data of ntuple
   */
  static float *pdist, *pconc, *pwidth, *plength;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */
    {
      /* get location of different variable names in event-data
       */
      pdist   = cts_pset_nam (pntuple, cDIST);
      pconc   = cts_pset_nam (pntuple, cCONC);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      plength = cts_pset_nam (pntuple, cLENGTH);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* apply scuts - including filter cuts
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) && *plength < 0.3f
      && *plength > 0.16f && *pwidth < 0.15f && *pwidth > 0.07f
      && *pconc > 0.4f)
    {
      /* all passed events are considered signal events
       * (ALPHA will be changed and is therefore meaningless here)
       */
      *bsig = true;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bdscuts97 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply original dynamical scuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  double dls, dad, dht, dcutlh, dcutll, dcutwh, dcutwl, dcutch, dcutcl;
  double dcuthl;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *pmdist, *paltdeg, *pwidth, *plength, *pconc;
  static float *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pconc   = cts_pset_nam (pntuple, cCONC);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pmdist  = cts_pset_nam (pntuple, cMDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }

  dls = log10 ((double) *psize);
  dad = (double) *paltdeg;
  dht = (double) (*pdist - *pmdist);


  /* apply dynamical scuts - including filter cuts;
   * (first derive cut boundaries, then apply the cuts)
   */
  bkeep = false;
  dcutlh = dcutwh = dcutch = dcuthl = dcutll = dcutwl = dcutcl = 0.;

  if (0.5 < *pdist && *pdist < 0.8)
    {
      dcutlh = cts_mcuto (dls, dad, 1.19036, 0.980757, 0.170714, 0.0184124,
			  -0.0718053, 0.0913398, -0.0336004, 0.00376545,
			  0.000568473, -0.000748999, 0.000294762, -0.0000364597);

      dcutll = cts_mcuto (dls, dad, -2.34962, 2.84021, -1.05459, 0.123668,
			  0.0534697, -0.0584963, 0.0207569,-0.00218114,
			  -0.000373666, 0.000395676, -0.000133401, 0.0000129945);


      dcutwh = cts_mcuto (dls, dad, 0.911201, -0.713875, 0.124025, 0.011091,
			  -0.0494004, 0.0598582, -0.0219576, 0.00248479,
			  0.000418959, -0.000521647, 0.000203062, -0.0000248613);

      dcutwl = cts_mcuto (dls, dad, -1.44981, 1.85022, -0.758222, 0.100109,
			  0.0318973, -0.044205, 0.0200009, -0.00274656,
			  -0.000205256, 0.000295974, -0.000137701, 0.0000192769);


      dcutch = cts_mcuto (dls, dad, 2.71197, -1.25739, 0.274738, -0.004953,
			  -0.0519297, 0.0438086, -0.0166526, 0.00173974,
			  0.000204679, -0.000172535, 0.0000836936, -0.0000106198);

      dcutcl = cts_mcuto (dls, dad, 3.4969, -4.46318, 2.14281, -0.320405,
			  -0.0969334, 0.132604, -0.0600206, 0.00846923,
			  0.000728087, -0.000954548, 0.000410947, -0.0000555756);


      dls = (dls > 3.954) ? 3.954 : dls;
      dcuthl = cts_mcuto (dls, dad, 0.266089, -1.22827, 0.79616, -0.167995,
			  0.0591657, -0.0663533, 0.0225148, -0.00157907,
			  -0.000617422, 0.000784941, -0.000308484, 0.000033587);
    }

  else if (0.8 < *pdist && *pdist < 1.1)
    {
      dcutlh = cts_mcuto (dls, dad, 0.0540586, 0.668754, -0.419966, 0.0721758,
			  -0.0131913, 0.00945466, -0.00062049, -0.000313049,
			  0.000100435, -0.0000872456, 0.0000169673, 8.94965e-8);

      dcutll = cts_mcuto (dls, dad,-0.653292, 0.164615, 0.147703, -0.0373323,
			  0.0323574, -0.0178379, 0.00158194, 0.000326205,
			  -0.000281999, 0.000201988, -0.0000435241, 1.87936e-6);


      dcutwh = cts_mcuto (dls, dad, -0.860858, 1.04732, -0.326931, 0.0288026,
			  0.00159757, 0.00180096, -0.00331662, 0.000883303,
			  0.0000201473, -0.0000400465, 0.0000315345, -7.01631e-6);

      dcutwl = cts_mcuto (dls, dad, -0.60864, 0.857768, -0.368289, 0.0573878,
			  0.0363869, -0.0487501, 0.0210685, -0.00302578,
			  -0.000363995, 0.000480565, -0.00020514, 0.000028817);


      dcutch = cts_mcuto (dls, dad, -1.58731, 3.03812, -1.11798, 0.109713,
			  0.116266, -0.134667, 0.0469623, -0.00489749, -0.0010245,
			  0.00114931, -0.000396013, 0.0000418562);


      dcutcl = cts_mcuto (dls, dad, -0.555555, 1.96449, -0.890388, 0.112722,
			  0.108433, -0.161118, 0.0703312, -0.00948812,
			  -0.000901089, 0.00130207, -0.000571321, 0.0000783964);


      dls = (dls > 3.954) ? 3.954 : dls;
      dcuthl = cts_mcuto (dls, dad, 6.01018, -8.35925, 3.56221, -0.465929,
			  -0.200242, 0.27268, -0.115226, 0.014939, 0.00137508,
			  -0.00187826, 0.000789943, -0.000101889);
    }


  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) && *plength > dcutll
      && *plength < dcutlh && *pwidth > dcutwl && *pwidth < dcutwh
      && *pconc > dcutcl && *pconc < dcutch && dht > dcuthl)
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  return (bkeep);
}


static bool bdscuts (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  double dm, dm2, dmls, dmls2, dmcza;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *pmdist, *paltdeg, *pwidth, *plength, *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      pmdist  = cts_pset_nam (pntuple, cMDIST);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dm = (double) *pmdist;
  dm2 = m2 (dm);

  dmls = log10 ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical scuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) &&

      *plength < cts_mcut (0.312335, -0.066047, 0.757547, 0.135425, 0.143054,
			   -0.990116, -0.121686, 0.270666, dmls, dmcza, dm, dmls2, dm2) &&

      *pwidth  < cts_mcut (0.125132, -0.030704, 0.027329, 0.077992, -0.023585,
			   0.055679, 0.003924, 0.006753, dmls, dmcza, dm, dmls2, dm2)   &&

      *pdist   < cts_mcut (1.009947, 0.0, 0.273654, 0.311418, 0.0,
			   -0.330804, 0.360062, 0.0, dmls, dmcza, dm, dmls2, dm2)       &&

      *pdist   > cts_mcut (0.720948, 0.0, 0.321872, 0.120119, 0.0,
			   0.200394, 0.053261, 0.0, dmls, dmcza, dm, dmls2, dm2))
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bdscuts2 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  double dm, dm2, dmls, dmls2, dmcza;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *pmdist, *paltdeg, *pwidth, *plength, *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      pmdist  = cts_pset_nam (pntuple, cMDIST);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dm = (double) *pmdist;
  dm2 = m2 (dm);

  dmls = log10 ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical scuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) &&

      *plength < cts_mcut (0.302323, 0.010247, 0.020944, 0.011791, -0.003160,
			   0.171213, 0.015246, -0.027715 , dmls, dmcza, dm, dmls2, dm2) &&

      *pwidth  < cts_mcut (0.139207, -0.004137, 0.018650, 0.026070, 0.005189,
			   0.026045, 0.006197, 0.006252, dmls, dmcza, dm, dmls2, dm2)   &&

      *pdist   < cts_mcut (1.105956, 0.0, 0.948818, 0.001871, 0.0,
			   0.039692, -0.001145, 0.0, dmls, dmcza, dm, dmls2, dm2)       &&


      *plength > cts_mcut (0.184105, 0.018415, 0.282785, 0.005554, 0.003405,
			   0.009151, -0.059313, -0.057837, dmls, dmcza, dm, dmls2, dm2)  &&


      *pwidth  > cts_mcut (0.14459, -0.021306, -0.009976, -0.037579, -0.048138,
			   0.012733, 0.019532, -0.002441, dmls, dmcza, dm, dmls2, dm2)  &&


      *pdist   > cts_mcut (0.499818, 0.0, 0.0008, 0.001552, 0.0,
			   0.000568, 0.000210, 0.0, dmls, dmcza, dm, dmls2, dm2))
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bds96 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version)
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.318797, 0.002084, 0.002366, 0.001916,
			       0.001673, 0.001890, 0.001752, 0.001782};

  static double widthup[8] = {0.131685, -0.003508, 0.001932, 0.001745,
			      0.001744, 0.017057, 0.000379, 0.000059};

  static double distup[8] = {1.071729, 0., 0.000296, 0.000533, 0., 0.001222,
			     0.000361, 0.};

  static double lengthlow[8] = {0.172638, 0.001578, -0.000412, 0.000623,
				0.000620, 0.052600, 0.000639, 0.000897};

  static double widthlow[8] = {0.077654, 0.001939, 0.005838, -0.001077,
			       0.000589, 0.002627, 0.000391, -0.003141};

  static double distlow[8] = {0.600160, 0., 0.000584, 0.007510, 0., 0.001807,
			      0.000157, 0.};

  static double alphaup[8] = {10.139156, 0., 0., 0., 0., 0., 0., 0.};


  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;

  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bds97 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version) - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.316225, 0.009228, 0.108804, 0.004296, 0.006888,
			       0.008337, -0.001450, 0.002367};

  static double widthup[8] = {0.152840, -0.009615, 0.005060, 0.002465,
			      -0.002912, 0.028525, 0.002092, -0.001813};

  static double distup[8] = {1.109032, 0., 0.000352, 0.000618, 0., 0.000735,
			     0.002775, 0.};

  static double lengthlow[8] = {0.199627, -0.000416, -0.000519, -0.000726,
				0.000643, 0.020667, 0.000879, -0.005145};

  static double widthlow[8] = {0.075761, 0.000973, 0.000873, 0.000388, 0.000215,
			       0.119446, 0.000117, 0.000098};

  static double distlow[8] = {0.581981, 0., -0.000058, -0.000384, 0., 0.000538,
			      -0.000661, 0.};

  static double alphaup[8] = {12.316064, 0., 0., 0., 0., 0., 0., 0.};


  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bds98 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version) - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.314470, -0.002971, 0.214955, 0.014255,
			       -0.005762, 0.015939, 0.002743, -0.005878};

  static double widthup[8] = {0.116007, -0.005906, 0.011251, 0.007428,
			      -0.006863, 0.010321, 0.001398, 0.001587};

  static double distup[8] = {0.835364, 0., 0.071450, 0.018148, 0., 0.015871,
			     0.011726, 0.};

  static double lengthlow[8] = {0.119287, 0.049070, 0.012912, -0.005003,
				0.015873, 0.071840, -0.031910, 0.018795};

  static double widthlow[8] = {0.027638, 0.020127, 0.781697, 0.018907,
			       -0.038871, 0.021489, -0.008433, -0.007781};

  static double distlow[8] = {0.668898, 0., 0.014071, 0.010763, 0., 0.104859,
			      -0.002099, 0.};

  static double alphaup[8] = {10.285300, 0., 0., 0., 0., 0., 0., 0.};


  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bds00 (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version)
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.269078, 0.007698, 0.080147, 0.004474, 0.003348,
			       -0.017267, -0.000100, 0.000107};

  static double widthup[8] = {0.137125, 0.007108, -0.015905, 0.004724,
			      -0.000560, 0.003510, 0.000405, -0.000729};

  static double distup[8] = {1.031978, 0., 0.218746, 0.000056, 0., 0.098147,
			     -0.000555, 0.};

  static double lengthlow[8] = {0.117132, 0.103052, 2.415260, 0.004454,
				-0.033575, 0.124739, 0.000548, 0.005296};

  static double widthlow[8] = {0.098692, 0.006271, 0.028279, -0.003236,
			       0.003737, 4.416664, 0.002475, 0.001833};

  static double distlow[8] = {0.544577, 0., 0.008668, 0.005881, 0., 0.005714,
			      0.000904, 0.};

  static double alphaup[8] = {12.361155, 0., 0., 0., 0., 0., 0., 0.};

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;

  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool btest (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version) - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.316605, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double widthup[8] = {0.142459, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double distup[8] = {1.065755, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double lengthlow[8] = {0.152921, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double widthlow[8] = {0.065391, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double distlow[8] = {0.602994, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  static double alphaup[8] = {11.410206, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bds97hiz (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply dynamical scuts (new version, high zenith angles)
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  static double dd, dd2, dmls, dmls2, dmcza, dcut_val;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *paltdeg, *pwidth, *plength, *palpha;

  /* cut parameters
   */
  static double lengthup[8] = {0.308737, 0.004986, 0.008862, -0.000937, -0.018228, -0.005259, -0.006537, 0.016993};

  static double widthup[8] = {0.111233, -0.007834, -0.006325, 0.015588, -0.005264, 0.034320, 0.001420, -0.000733};

  static double distup[8] = {1.088853, 0.000000, -0.001774, -0.002321, 0.000000, -0.002348, -0.002907, 0.000000};

  static double lengthlow[8] = {0.127094, -0.003495, -0.003741, -0.004349, -0.004300, -0.004422, -0.004484, -0.003970};

  static double widthlow[8] = {0.053949, -0.003642, -0.000501, -0.000706, -0.000235, 0.000788, 0.001309, 0.001054};

  static double distlow[8] = {0.501753, 0.000000, 0.000130, 0.000027, 0.000000, -0.000268, 0.000446, 0.000000};

  static double alphaup[8] = {10.605777, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};


  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dd = (double) *pdist;
  dd2 = m2 (dd);

  dmls = log ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;

  /* apply dynamical cuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig)

      && *plength < (float) cts_mncut (lengthup, dmls, dmcza, dd, dmls2, dd2)
      && *plength > (float) cts_mncut (lengthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pwidth < (float) cts_mncut (widthup, dmls, dmcza, dd, dmls2, dd2)
      && *pwidth > (float) cts_mncut (widthlow, dmls, dmcza, dd, dmls2, dd2)

      && *pdist < (float) cts_mncut (distup, dmls, dmcza, dd, dmls2, dd2)
      && *pdist > (float) cts_mncut (distlow, dmls, dmcza, dd, dmls2, dd2))
    {
      /* set bsig (all events below ALPHA-cut are considered signal events)
       */
      dcut_val = cts_mncut (alphaup, dmls, dmcza, dd, dmls2, dd2);
      *bsig = (fabs (*palpha) < (float) dcut_val) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


static bool bhza_cuts (HBOOK_FILE *pntuple, RUN_TYPE rtyp, bool *bsig)

  /* apply high ZA. cuts - filter cuts are included
   * pntuple - contains variables to acces Ntuple events
   * rtyp    - run type of events (MC, ON, OFF ...) (not used here)
   * bsig    - true for events in signal region, else false
   */
{
  /* auxiliary variables
   */
  double dm, dm2, dmls, dmls2, dmcza;

  /* array to store hbook file name - it's used to check whether we're
   * dealing with a new ntuple (FILENAME_MAX is defined in stdio.h)
   */
  static char cfile_name[FILENAME_MAX] = "";

  /* pointers to cut variables in event data of ntuple
   */
  static float *psize, *pdist, *pmdist, *paltdeg, *pwidth, *plength, *palpha;

  bool bkeep;


  if (strcmp (cfile_name, pntuple->pname))

    /* cuts are applied to a new ntuple, so check for position
     * of used variables
     */    
    {
      /* get location of different variable names in event-data
       */
      psize   = cts_pset_nam (pntuple, cSIZE);
      pdist   = cts_pset_nam (pntuple, cDIST);
      pwidth  = cts_pset_nam (pntuple, cWIDTH);
      pmdist  = cts_pset_nam (pntuple, cMDIST);
      palpha  = cts_pset_nam (pntuple, cALPHA);
      plength = cts_pset_nam (pntuple, cLENGTH);
      paltdeg = cts_pset_nam (pntuple, cALTDEG);

      /* reset file name
       */
      strncpy (cfile_name, pntuple->pname, (size_t) FILENAME_MAX);
    }


  /* calculate auxiliary variables
   */
  dm = (double) *pmdist;
  dm2 = m2 (dm);

  dmls = log10 ((double) *psize) - dNOMLOGSIZE;
  dmls2 = m2 (dmls);

  dmcza = cos ((double) (90.f - *paltdeg) * dPIDIV180) - dNOMCOSZA;


  /* apply dynamical scuts - including filter cuts;
   */
  if (cut_funcs[FILTER] (pntuple, rtyp, bsig) &&

      *plength < cts_mcut (0.24103, 0.139459, 0.62207, 0.664643, 0.201824,
		       0.706092, 0.355163, 0.350056, dmls, dmcza, dm, dmls2, dm2)    &&

      *pwidth  < cts_mcut (0.120748, -0.013991, -0.040156, -0.008711, -0.006767,
		       0.062188, 0.057057, -0.001869, dmls, dmcza, dm, dmls2, dm2)   &&

      *pdist   < cts_mcut (1.126741, 0.0, 0.211918, -0.297835, 0.0, -0.165264,
		       0.235489, 0.0, dmls, dmcza, dm, dmls2, dm2)                   &&

      *plength > cts_mcut (0.162537072, 0.004144, 0.003119, -0.003170, -0.001088,
		       0.002088, -0.013223, -0.018980, dmls, dmcza, dm, dmls2, dm2)  &&

      *pwidth  > cts_mcut (0.05834475, -0.019649, -0.020870, -0.018830, -0.013345,
		       -0.012524, -0.011768, -0.002691, dmls, dmcza, dm, dmls2, dm2) &&

      *pdist   > cts_mcut (0.490393, 0.0, 0.581015, 0.465913, 0.0,
		       0.062311, 0.034295, 0.0, dmls, dmcza, dm, dmls2, dm2))
    {
      /* set bsig (all events below dALPHA_CUT are considered signal events)
       */
      *bsig = (fabs ((float) *palpha) < dALPHA_CUT) ? true : false;

      bkeep = true;
    }

  else
    bkeep = false;

  return (bkeep);
}


bool cts_bcuts (CUT_TYPE ctyp, HBOOK_FILE *pntuple, RUN_TYPE rtyp,
		bool (*pcut_func) (HBOOK_FILE *), bool *bsig)

  /* interface to all defined cuts;
   * checks rtyp and ctyp too
   * pcut_func - user supplied cut function (or null)
   */
{
  bool bcutval;

  /* use dummy cut if there's no user supplied cut
   */
  if (pcut_func == NULL)
    pcut_func = bnocut2;


  if (0 <= rtyp && rtyp < MAX_RUN_TYPE && 0 <= ctyp && ctyp < MAX_CUT_TYPE)
    {
      bcutval = (* cut_funcs[ctyp]) (pntuple, rtyp, bsig);
      bcutval &= pcut_func (pntuple);
    }

  else
    cts_merror ("%s: unknown cut or data type!\n", "cts_bcuts");

  return (bcutval);
}


CUT_TYPE cts_cut_type (char *pcutnam)

  /* this functions returns the enum corresponding to the passe cut-name
   * or 'MAX_CUT_TYPE' if cut is unknown
   */
{
  int i;

  CUT_TYPE ctyp;


  ctyp = MAX_CUT_TYPE;

  for (i = 0; i < MAX_CUT_TYPE; i++)
    {
      if (strncmp (pcutnam, &cut_names[i][0], (size_t) iMAX_CUT_NAME_LEN) == 0)
	ctyp = (CUT_TYPE) i;
    }

  return (ctyp);
}


double cts_dsig (double dnon, double dnoff, double dnon_n, double dnoff_n)

  /* calculate significance according to Zhang & Ramsden (Exp. Astr. 1: 145-163,
   * 1990) the best way of doing this is by FISHER'S EXACT TEST. The final
   * Probability (formula 30) can be calculated using the incomplete beta
   * function
   */
{
  double r, prob, sig;

  /* increase dnon_n and dnoff_n if too small; whole procedure must be changed
   * to use the obs. time
   */
  dnon_n += (dnon_n < 1.) ? 1. : 0.;
  dnoff_n += (dnoff_n < 1.) ? 1. : 0.;

  r = dnon_n / dnoff_n;
  prob = betai (dnon, dnoff + 1., r / (1. + r));

  /* derive Significance as quantile from SND or use Li & Ma formula 17, if
   * probability is too small
   */
  if (prob > 1e-300)
    sig = cts_dsnd_quant (prob / 2.);

  else
    {
      r = dnon_n / dnoff_n;
      sig = M_SQRT2 * sqrt (dnon * log ((1. + r) / r * dnon / (dnon + dnoff))
			    + dnoff * log ((1. + r) * dnoff / (dnon + dnoff)));
    }

  return (sig);
}
