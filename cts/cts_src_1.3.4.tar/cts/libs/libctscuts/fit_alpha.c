#include <stdio.h>
#include <math.h>
#include <math.h>
#include <stdio.h>
#include "ctsbase.h"
#include "ctsmath.h"
#include "ctshbook.h"
#include "ctscuts.h"
#include "nr.h"


static double devt_ex (double a[], double damin, double damax)

  /* this function is used to get number of excess events; it uses the
   * gaussian part of the fitted function vfunc (and must therefore be
   * consistent with that function)
   * input:
   * a     - array of fit parameters
   * damin - minimum ALPHA for signal region
   * damax - maximum ALPHA for signal region
   */
{
  double dxmin, dxmax, dex_evts;

  dxmin = mdiv (damin, fabs (a[4]) * M_SQRT2);
  dxmax = mdiv (damax, fabs (a[4]) * M_SQRT2);


  dex_evts = 0.5 * a[3] * (cts_derfc (dxmin) - cts_derfc (dxmax)) / dALPHA_BINW;

  return (dex_evts);
}



static double devt_off (double a[], double damin, double damax)

  /* this function is used to get number of background events; it uses the
   * polynomial part of the fitted function vfunc (and must therefore be
   * consistent with that function)
   * input:
   * a     - array of fit parameters
   * damin - minimum ALPHA for normalization region
   * damax - maximum ALPHA for normalization region
   */
{
  double doff_evt;

  doff_evt = (a[1] * (damax - damin) + a[2] * (m3 (damax) - m3 (damin)) / 3.)
    / dALPHA_BINW;

  return (doff_evt);
}


static void vfunc (double x, double a[], double *yval, double dyda[], int ima)

  /* this function is fitted to the ALPHA-distribution of the data; it
   * consists of a gaussian part and a polynomial of 2nd order
   * (function used here must be consistent with dgevt_on and dgevt_off)
   * input:
   * x    - ALPHA value
   * a    - array of function parameters
   * ima  - elements of a and dyda
   * output:
   * yval - function value at x
   * dyda - partial derivatives
   * remark: Numerical Recipes vetors start at '1' not '0'
   */
{
  double dsigma, dgauss;


  /* check ima
   */
  if (ima != 4) cts_merror ("vfunc: array size %d (expected: 4)", ima);


  /* sigma = a[4] might be '0' so use dEPSILON instead
   */
  dsigma = (fabs (a[4]) > dEPSILON) ? fabs (a[4]) : dEPSILON;

  dgauss = exp (-0.5 * m2 (x / dsigma)) / dSQRT_2PI / dsigma;


  /* set derivatives
   */
  dyda[1] = 1.;
  dyda[2] = m2 (x);
  dyda[3] = dgauss;
  dyda[4] = a[3] * dgauss * (m2 (x / dsigma) - 1.) / dsigma;


  /* set function value
   */
  *yval = a[1] + a[2] * m2 (x) + a[3] * dgauss;
}




double cts_dfit_alpha (double *y, double *y_err, double dasig, RESULT *presults,
		       double **pfpar, bool blog)

  /* fit function to ALPHA distribution and calculate event numbers
   * and significance
   * input:
   * y     - array of ALPHA distribution
   * y_err - error on y
   * dasig - upper ALPHA boundary for signal region
   * blog  - true if results should be logged
   * output:
   * presults - struct containing results (evt. numbers and signal)
   * pfpar    - pointer to fit parameters
   * return:
   * chisquare
   */
{
  int i, k, itst;
  static int *ia;

  double dnr_ex, dnr_off, dnr_off_n, doff_cmp, doff_gauss;
  double dy, dy_diff, alamda, chisq, chisq_old, dacmp = 25.;
  static double *fitpars, *x, **alpha, **covar;

  static bool bdone, binit = true;

  static FILE_TYPE log_file;



  if (binit)
    {
      /* define Numerical Recipes (NR) vectors
       */
      ia      = ivector (1, iMA);
      fitpars = vector (1, iMA);
      x       = vector (1, iNPT);
      alpha   = matrix (1, iMA, 1, iMA);
      covar   = matrix (1, iMA, 1, iMA);


      /* init arrays:
       * x  - mean values of ALPHA bins
       * ia - '1' if variable, '0' if fixed
       * (element 0 is not used in the NR fit routines)
       */
      for (i = 1; i <= iNPT; i++)
	x[i] = cts_malpha_mean (i);

      for (i = 1; i <= iMA; i++)
	ia[i] = 1;


      /* open file to log fit results
       */
      log_file.pname = "fit_alpha.log";
      log_file.pfile = NULL;
      log_file.acm = "w+";

      cts_vopen_file (&log_file);

      binit = false;
    }



  /* init fit parameter with guess values:
   * const. term taken as number of events at ALPHA = 20
   * amplitude of gaussian (fitpar[3]) is number of excess events in first
   * ALPHA bin mult. by sqrt (2*pi*sigma^2)
   * fitpars[4] = sigma;
   */
   fitpars[1] = y[4];
   fitpars[2] = (y[iNPT] - y[4]) / m2 (dALPHA_BINW * (double) iNPT);
   fitpars[3] = (y[1] - y[4]) * 12.5;
   fitpars[4] = 5.;


  /* init fit-routine
   */
  alamda = -1;
  mrqmin (x, y, y_err, iNPT, fitpars, ia, iMA, covar, alpha, &chisq, vfunc,
	  &alamda);


  /* consecutive calls to mrqmin until chisq converges
   */
  k = 1;
  itst = 0;
  bdone = false;

  while (!bdone)
    {
      /* update logfile (if needed)
       */
      if (blog)
	{
	  fprintf (log_file.pfile, cWRITE_LOG, k++, chisq, alamda);
	  fprintf (log_file.pfile, cHEAD_LOG);

	  for (i = 1; i <= iMA; i++)
	    fprintf (log_file.pfile, "%11.4f ", fitpars[i]);

	  fprintf (log_file.pfile, "\n\n");
	}


      /* next iteration
       */
      chisq_old = chisq;
      mrqmin (x, y, y_err, iNPT, fitpars, ia, iMA, covar, alpha, &chisq, vfunc,
	      &alamda);

      if (chisq > chisq_old)
	itst = 0;

      else
	if (fabs (chisq_old - chisq) < 0.01)
	  {
	    itst++;
	    bdone = (itst < 4) ? false : true;
	  }

	else
	  itst = 0;
    }



  /* update logfile (if needed)
   */
  if (blog)
    {
      /* derive covariance matrix - alamda = 0. triggers calculation
       */
      alamda = 0.;
      mrqmin (x, y, y_err, iNPT, fitpars, ia, iMA, covar, alpha, &chisq, vfunc,
	      &alamda);

      fprintf (log_file.pfile, "\n\n Uncertainties:\n");

      for (i = 1; i <= iMA; i++)
	fprintf(log_file.pfile, "%12.4f ", sqrt (covar[i][i]));
    }



  /* calculate results and apply corrections
   * (set everything to '0', if fit routine failed (chisq == -1) of if
   *  min number of events not available)
   */
  for (dy = 0., i = 1; i <= iNPT; i++)
    dy += y[i];

  if (chisq < 0. || dy < 40.)
    {
      presults->dsignal = 0.;
      presults->dnr_ex = presults->dnr_off = presults->dnr_off_n = 0.;
      *pfpar = fitpars;

      return (chisq);
    }


  dnr_ex    = devt_ex  (fitpars, 0., dasig);
  dnr_off   = devt_off (fitpars, 0., dasig);
  dnr_off_n = devt_off (fitpars, dALPHA_NLO, dALPHA_NHI);


  /* the gaussian type signal peak should be zero at large ALPHA values
   * (~ dacmp); if not, the area of the gauss peak below y = gauss (dacmp)
   * is regarded as off data, subtracted from dnr_ex and added to dnr_off;
   */
  doff_gauss = devt_ex (fitpars, dacmp - dALPHA_BINW, dacmp) * dasig
    / dALPHA_BINW;

  dnr_ex  -= doff_gauss;
  dnr_off += doff_gauss;


  /* to avoid artificial optimization we compare dnr_off with the number of
   * events at ALPHA ~ dacmp; if the latter is higher we take it (don't forget
   * to include doff_gauss and change dnr_ex as well)
   */
  doff_cmp = devt_off (fitpars, dacmp - dALPHA_BINW, dacmp) * dasig
    / dALPHA_BINW + doff_gauss;


  if (doff_cmp > dnr_off)
    {
      dnr_ex -= (doff_cmp - dnr_off);
      dnr_off = doff_cmp;
    }


  /* it might happen that the fit is poor and the fit-function does not
   * agree with the event numbers for small ALPHAs; here we try to correct
   * this 
   */
  dy_diff = devt_ex  (fitpars, 0., dALPHA_BINW)
    + devt_off (fitpars, 0., dALPHA_BINW) - y[1];

  if (dy_diff > 0.)
    dnr_ex -= dy_diff * dasig / dALPHA_BINW;


  /* fill results struct & set pointer to fit pars
   */
  presults->dnr_ex = dnr_ex;
  presults->dnr_off = dnr_off;
  presults->dnr_off_n = dnr_off_n;
  presults->dex_err = sqrt (2. * dnr_off + dnr_ex);
  presults->dsignal = cts_dsig (dnr_off + dnr_ex, dnr_off, dnr_off_n,
				dnr_off_n);


  *pfpar = fitpars;

  return (chisq);
}
