/*
 *  some statistic routines
 *
 *  Daniel Kranich
 *  26.02. 2000
 */
#include <stdio.h>
#include <math.h>
#include "ctsbase.h"
#include "ctsmath.h"


void cts_vget_svar (double x[], int inp, double *dmean, double *dsvar)

  /* this function calculates the mean and sample variance of a
   * given data sample 'x[]' consisting of 'inp' points;
   * the results are returned in 'dmean' and 'dsvar'
   */
{
  int i;

  /* expectation value of x and x^2
   */
  double dev_x, dev_x2;


  dev_x = dev_x2 = 0.;
  for (i = 0; i < inp; i++)
    {
      dev_x  += x[i];
      dev_x2 += m2 (x[i]);
    }

  *dmean = dev_x / (double) inp;
  *dsvar  = (dev_x2 - dev_x * dev_x / (double) inp) / (double) (inp - 1);
}


double cts_derfc (double x)

  /* complementary error function (based on Chebychev fit)
   */
{
  double dx, dt, res;

  dx = fabs (x);
  dt = 1.0 / (1.0 + 0.5 * dx);

  res = dt * exp (-dx * dx - 1.26551223 + dt * (1.00002368 + dt * (0.37409196
	+ dt * (0.09678418 + dt * (-0.18628806 + dt * (0.27886807
        + dt * (-1.13520398 + dt * (1.48851587 + dt * (-0.82215223
        + dt * 0.17087277)))))))));

  return (x < 0. ? 2.0 - res : res);
}


static double ddsnd_prob;

static void vsnd_quant_func (NRB_STRUCT *nrb)

  /* used by cts_dsnd_quant
   */
{
  double x, dx = 1e-10;

  x = nrb->x / M_SQRT2;

  nrb->f = 0.5 * cts_derfc (x) - ddsnd_prob;
  nrb->df = (cts_derfc (x) - cts_derfc (x + dx)) / dx;
}

double cts_dsnd_quant (double dprob)

  /* calculates quantile of standard normal distribution
   * (uses vsnd_quant_func; q&d implementation - has to be changed)
   */
{
  double dquant, dacc;

  dprob = fabs (dprob);
  ddsnd_prob = (dprob > 0.5) ? 1. - dprob : dprob;
  dacc = ddsnd_prob / 1e10;

  /* 1e10 should be reasonably high but look for a better solution
   */
  if (fabs (ddsnd_prob - 0.5) > dEPSILON)
    cts_bfind_root (NRB, vsnd_quant_func, 1e10, 0., dacc, &dquant);

  else
    dquant = 0.;

  printf ("prob: %E, quantile: %f\n", dprob, dquant);

  return (dquant);
}
