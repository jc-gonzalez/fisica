#! /bin/sh

theta=0.
phi=0.
focal=1700.
height=10.e5

for t in 0.0 0.5 1.0 1.5 2.0 2.5; do

    tt=`echo $t | tr -d '.'`

    for modo in 1 3; do
    
        if [ "$modo" = "1" ]; then

            outfile=th${tt}
            outfiledat=${outfile}.dat
            mdef=magic-perfect.definition
            atm=ATM_NOATMOSPHERE
            axisdev=0.0

            rm -rf *.mirr axisdev.dat
            ln -sf reflectivity-100.dat reflectivity.dat

        elif [ "$modo" = "2" ]; then

            outfile=th${tt}_atm
            outfiledat=${outfile}.dat
            mdef=magic-perfect.definition
            atm=ATM_CORSIKA
            axisdev=0.0

            rm -rf *.mirr axisdev.dat
            ln -sf reflectivity-100.dat reflectivity.dat

        else

            outfile=th${tt}_refl
            outfiledat=${outfile}.dat
            mdef=m.def
            atm=ATM_NOATMOSPHERE
            axisdev="0.0 0.1 0.2 0.3 0.4 0.5"

            rm -rf *.mirr axisdev.dat
            ln -sf reflectivity-90.dat reflectivity.dat

        fi

        for a in $axisdev; do    

            if [ "$modo" = "3" ]; then

                outfile=th${tt}_refl_axisdev$a
                outfiledat=${outfile}.dat
                awk -v ad=$a '
                    (/adjustment_dev/) {print "adjustment_dev   ",ad;next;}
                                       {print}' m.def.tpl | \
                sed -e "s/@focal/$focal/g" > m.def

                rm -rf *.mirr axisdev.dat
            fi

            cat <<EOF>pb.par
reflector 0.3                                      -*- sh -*-
verbose_level 4
#fixed_target  0. 0.
#range_events 1 2946
#skip 1 2946
#range_events 381 382
#max_events   2
#energy_cuts   800. 1000.
ct_file       $mdef      
#output_file   /hd80/MC/CT1/ana/g_magic_run16.rfl
#atm_model     ATM_CORSIKA
atm_model     $atm
data_paths 1
./
#data_from_stdin
#data_to_stdout
output_file   ./pb.rfl
parallel_beam  $t $phi 0. 0. 2000. 2000. 400 400 $height
#pm_parallel_beam unnamed.ppm 2. 10000.
end_file
EOF

            echo Generating spot data files $outfile . . .
    
            ./reflector -f pb.par 2> errors | \
                awk '(/^@4/) {print $3,$4;}' > $outfiledat
    
            ls -1s ${outfile}*

        done

    done

done

exit 0

#EOF