#! /bin/sh

height=$1
# theta=$2
# phi=$3
# focal=$4
theta=0.
phi=0.
focal=1700.

sed -e "s/@focal/$focal/g" m.def.tpl > m.def

cat <<EOF>pb.par
reflector 0.3                                      -*- sh -*-
verbose_level 4
#fixed_target  0. 0.
#range_events 1 2946
#skip 1 2946
#range_events 381 382
#max_events   2
#energy_cuts   800. 1000.
ct_file        m.def
#output_file   /hd80/MC/CT1/ana/g_magic_run16.rfl
#atm_model     ATM_CORSIKA
atm_model     ATM_NOATMOSPHERE
data_paths 1
./
#data_from_stdin
#data_to_stdout
output_file   ./pb.rfl
parallel_beam  $theta $phi 0. 0. 1900. 1900. 200 200 $height
#pm_parallel_beam unnamed.ppm 2. 10000.
end_file
EOF

./reflector -f pb.par |awk '(/^@4/) {print $3,$4,$6,$7,$8;}'

exit 0

#EOF