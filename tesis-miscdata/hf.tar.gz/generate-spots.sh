#! /bin/sh

theta=0.
phi=0.
focal=1700.

for m in m m_inf; do

    if [ "$m" = "m" ]; then
        hfs=10km
    else
        hfs=inf
    fi
        
    sed -e "s/@focal/$focal/g" ${m}.def.tpl > m.def

    for h in 5 10 12 100 999; do

        if [ "$h" = "999" ]; then
            height=1.0e11   # 10^6 km
            hls=inf
        else
            height=${h}.0e5 # km to cm
            hls=${h}km
        fi
        
        outfile=hf${hfs}_hl${hls}
        outfiledat=${outfile}.dat

        cat <<EOF>pb.par
reflector 0.3                                      -*- sh -*-
verbose_level 4
#fixed_target  0. 0.
#range_events 1 2946
#skip 1 2946
#range_events 381 382
#max_events   2
#energy_cuts   800. 1000.
ct_file        m.def
#output_file   /hd80/MC/CT1/ana/g_magic_run16.rfl
#atm_model     ATM_CORSIKA
atm_model     ATM_NOATMOSPHERE
data_paths 1
./
#data_from_stdin
#data_to_stdout
output_file   ./pb.rfl
parallel_beam  $theta $phi 0. 0. 1900. 1900. 500 500 $height
#pm_parallel_beam unnamed.ppm 2. 10000.
end_file
EOF

        rm -rf *.mirr

        echo Generating spot data files $outfile . . .

        ./reflector -f pb.par 2> errors | \
            awk '(/^@4/) {print $3,$4,$6,$7,$8;}' > $outfiledat

        (echo $outfile; cat $outfiledat ) | \
            octave --silent camera_planes.m

        ls -1s ${outfile}*

    done

done

/cern/pro/bin/paw -b hf-createhistos.kumac

/cern/pro/bin/paw -b spots.kumac

exit 0

#EOF