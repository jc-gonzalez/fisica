1;

format compact

planes = 1696:1704;

fname = input('Enter filename: ', 's');

d = scanf("%f",[5,Inf])';
n = max(size(d));

for h=planes;

  if (h!=1700),
    x = (d(:,3) - d(:,1)) .* (h - 1700) ./ (d(:,5) - 1700) + d(:,1); 
    y = (d(:,4) - d(:,2)) .* (h - 1700) ./ (d(:,5) - 1700) + d(:,2); 
  else
    printf("h=1700, no calculations needed, ");
    x = d(:,1);
    y = d(:,2);
  endif

  coords = [x,y];

  save -ascii coords coords
  command = sprintf("mv coords %s_%4dcm.dat", fname, h);
  system(command);
  printf("saving data to file %s_%4dcm.dat. . .\n", fname, h);

#   for i=1:n,
#     printf("%5d%10.4g%10.4g\n", h, x(i), y(i));
#   endfor

endfor

## Local Variables:
## mode:octave
## End:
